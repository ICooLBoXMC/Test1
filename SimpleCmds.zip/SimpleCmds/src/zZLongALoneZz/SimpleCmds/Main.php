<?php

namespace zZLongALoneZz\SimpleCmds;

use pocketmine\Server;
use pocketmine\player\Player;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;

use pocketmine\command\CommandSender;
use pocketmine\command\Command;

class Main extends PluginBase implements Listener{
  
   public function onEnable(): void{
        $this->getLogger()->info("§aStarting SimpleCmds plugin...");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
    
   public function onDisable(): void{
        $this->getLogger()->info("§cDisabling SimpleCmds plugin...");
    }

   public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool{
       if($sender instanceof Player){
           if($cmd->getName() == "heal"){
           	if($sender->isSurvival()){
           	if(count($args) < 1){
               $sender->setHealth($sender->getMaxHealth());
               $sender->sendActionBarMessage("§aYou have been heal");
               return false; 
               }
               $ownername = $sender->getName();
               $name = implode($args);
               $player = Server::getInstance()->getPlayerByPrefix($name);
               if($player instanceof Player){
               	$sender->sendActionBarMessage("§aYou have been heal $player");
                   $player->setHealth($sender->getMaxHealth());
                   $player->sendActionBarMessage("§aYou have been heal\n§l§bBy:§r §1$ownername");
               }else{
                   $sender->sendMessage("§l§f[§r§cError§l§f]§r §3Player not found!");
                   }
               }else{
		           $sender->sendActionBarMessage("§bPlease use this command in survival mode!");
		           }
           }
           if($cmd->getName() == "feed"){
           	if($sender->isSurvival()){
           	if(count($args) < 1){
               $sender->getHungerManager()->setFood(20);
               $sender->getHungerManager()->setSaturation(20);
               $sender->sendActionBarMessage("§aYou have been feed");
               return false; 
               }
               $ownername = $sender->getName();
               $name = implode($args);
               $player = Server::getInstance()->getPlayerByPrefix($name);
               if($player instanceof Player){
               	$sender->sendActionBarMessage("§aYou have been feed $player");
                   $player->getHungerManager()->setFood(20);
                   $player->getHungerManager()->setSaturation(20);
                   $player->sendActionBarMessage("§aYou have feed heal\n§l§bBy:§r §1$ownername");
               }else{
                   $sender->sendMessage("§l§f[§r§cError§l§f]§r §3Player not found!");
                   }
               }else{
		           $sender->sendActionBarMessage("§bPlease use this command in survival mode!");
		           }
           }
           if($cmd->getName() == "fly"){
               if($sender->isSurvival()){
                if($sender->isFlying()){
                	$sender->setFlying(false);
                    $sender->setAllowFlight(false);
                    $sender->sendActionBarMessage("§cFly is Disabled");
                }else{
                    $sender->setFlying(true);
                    $sender->setAllowFlight(true);
                    $sender->sendActionBarMessage("§aFly is Enabled");
	                }
	            }else{
		            $sender->sendActionBarMessage("§bPlease use this command in survival mode!");
		   }
		   if($cmd->getName() == "seedevice"){
               if(count($args) < 1){
                   $sender->sendMessage("§bUsage /player <name>");
                   return false;
                   }
                   $name = implode($args);
                   $os = ["Unknown", "Android", "iOS", "macOS", "FireOS", "GearVR", "HoloLens", "Windows 10", "Windows", "Dedicated", "Orbis", "Playstation 4", "Nintento Switch", "Xbox One"];
                   $controls = ["Unknown", "Mouse & Keyboard", "Touch", "Controller"];
                   $player = Server::getInstance()->getPlayerByPrefix($name);
                   if($player instanceof Player){
                   $sender->sendMessage("§bPlayer: §f" . $player->getName() . "\n§bDevice: §f" . $os[$player->getPlayerInfo()->getExtraData()["DeviceOS"] ?? 0] . "\n§bPing: §f" . $player->getNetworkSession()->getPing() . "\n§bControl: §f" . $controls[$player->getPlayerInfo()->getExtraData()["CurrentInputMode"] ?? 0] . "\n§bDevice Model: §f" . $player->getPlayerInfo()->getExtraData()["DeviceModel"]);
               }else{
                   $sender->sendMessage("§l§f[§r§cError§l§f]§r §f» §3Player not found!");
            }
        }
    }
}else{
    $sender->sendMessage("Please use this command in game )33");
    }
    return true;
    }

}
